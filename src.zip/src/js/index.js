document.addEventListener("DOMContentLoaded", function() {
    registerFilterListeners();
    filterRooms();
})

//function to find all filter inputs on the page
function registerFilterListeners() {
    const searchInput = document.querySelector('input[type="search"]');
    const fearRadios = document.querySelectorAll('input[name="fear"]');
    const actorRadios = document.querySelectorAll('input[name="actor"]');
    const difficultyRadios = document.querySelectorAll('input[name="difficulty"]');
    const genreCheckboxes = document.querySelectorAll('input[type="checkbox"]');

    //runs filterrooms functions 
    if (searchInput) {
        searchInput.addEventListener('keyup', filterRooms);
    }
    
    fearRadios.forEach(radio => {
        radio.addEventListener('change', filterRooms);
    });
    
    actorRadios.forEach(radio => {
        radio.addEventListener('change', filterRooms);
    });

    difficultyRadios.forEach(radio => {
        radio.addEventListener('change', filterRooms);
    });
    
    genreCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', filterRooms);
    });
}


// the main filter function.
function filterRooms() {

    //basically finds if the room matches all the filter values and only shows it if it does else it wont show
    //also updates the room number with a counter
    const searchText = document.querySelector('input[type="search"]').value.toLowerCase();
    const fearValue = document.querySelector('input[name="fear"]:checked').value;
    const actorValue = document.querySelector('input[name="actor"]:checked').value;
    const difficultyValue = document.querySelector('input[name="difficulty"]:checked').value;
    //css selector ':checked' searches for the radio button pressed

    //checkbox: first generates an empty array and pushes values of checked checkbox into the array
    const checkedGenres = [];
    document.querySelectorAll('input[type="checkbox"]:checked').forEach(checkbox => {
        checkedGenres.push(checkbox.value);
    });

    //get all room cards and reset counter
    const roomCards = document.querySelectorAll('.room-card');
    let visibleCount = 0;

    //main loop
    roomCards.forEach(card => {
        
        //get data from the cards -> data labels in php
        const cardTitle = (card.dataset.title || '').toLowerCase();
        const cardFear = card.dataset.fear;
        const cardActor = card.dataset.actor;
        const cardGenre = card.dataset.genre;
        const cardDifficulty = card.dataset.difficulty;

        //does card title include text from the search bar
        const titleMatch = cardTitle.includes(searchText);
        //radio and checkbox logic
        const fearMatch = (fearValue === 'all' || fearValue === cardFear);
        const actorMatch = (actorValue === 'all' || actorValue === cardActor);
        const difficultyMatch = (difficultyValue === 'all' || difficultyValue === cardDifficulty);
        const genreMatch = (checkedGenres.length === 0 || checkedGenres.includes(cardGenre));

        //impt! only shows the room if ALL conditions are true! else nuh uh
        if (titleMatch && fearMatch && actorMatch && genreMatch && difficultyMatch) {
            card.style.display = 'block'; //show card
            visibleCount++;
        } else {
            card.style.display = 'none';  //hide card
        }
    });

    const roomContainer = document.getElementById('roomContainer');
    const noResultsDiv = document.getElementById('noResultsMessage');

    // attempting to make it so that the page wont abruptly move upwards when no matches found with the filter
    // not really working
    if (visibleCount === 0) {
        // Hide the room cards (in case they were not fully filtered out) and show the message
        if (roomContainer) {
             roomContainer.style.display = 'none'; 
        }
        if (noResultsDiv) {
            noResultsDiv.style.display = 'block';
        }
    } else {
        // Show the room cards and hide the message
        if (roomContainer) {
            roomContainer.style.display = 'flex'; // Use 'flex' or 'block' based on your CSS row setting
        }
        if (noResultsDiv) {
            noResultsDiv.style.display = 'none';
        }
    }

    //update the "Showing {num} rooms" text
    const roomCountText = document.querySelector('.text-center.my-4 p');
    if (roomCountText) {
        roomCountText.textContent = `Showing ${visibleCount} room${visibleCount !== 1 ? 's' : ''}`;
    }
}